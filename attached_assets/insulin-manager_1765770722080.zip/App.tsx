import React, { useState, useEffect } from 'react';
import { Home, BookOpen, UserCircle } from 'lucide-react';
import { Dashboard } from './components/Dashboard';
import { Logbook } from './components/Logbook';
import { Settings } from './components/Settings';
import { EntrySheet } from './components/EntrySheet';
import { AuthScreen } from './components/AuthScreens';
import { AppSettings, InsulinRecord, TimeSlot, DEFAULT_SETTINGS, User } from './types';
import { StorageService } from './services/storage';
import { AuthService } from './services/auth';
import { generateId } from './utils';

function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  
  // App State
  const [activeTab, setActiveTab] = useState<'dashboard' | 'logbook' | 'settings'>('dashboard');
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [records, setRecords] = useState<InsulinRecord[]>([]);
  const [isEntryOpen, setIsEntryOpen] = useState(false);
  const [currentEntrySlot, setCurrentEntrySlot] = useState<TimeSlot>('breakfast_pre');
  const [editingRecord, setEditingRecord] = useState<InsulinRecord | undefined>(undefined);

  // Initial Load: Check for logged in user
  useEffect(() => {
    const user = AuthService.getCurrentUser();
    if (user) {
      handleLogin(user);
    }
  }, []);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    // Load User Data
    setSettings(StorageService.getSettings(user.id));
    setRecords(StorageService.getRecords(user.id));
    setActiveTab('dashboard');
  };

  const handleLogout = () => {
    AuthService.logout();
    setCurrentUser(null);
    setRecords([]);
    setSettings(DEFAULT_SETTINGS);
  };

  const handleDeleteAccount = () => {
    if (currentUser) {
      AuthService.deleteAccount(currentUser.id);
      setCurrentUser(null);
      setRecords([]);
      setSettings(DEFAULT_SETTINGS);
    }
  };

  const handleSaveRecord = (record: Partial<InsulinRecord>) => {
    if (!currentUser) return;
    if (!record.slot) return; 
    
    const newRecord = {
      ...record,
      id: record.id || generateId(),
      userId: currentUser.id, // Bind to user
      date: record.date || new Date().toISOString().split('T')[0],
      timestamp: record.timestamp || Date.now(),
    } as InsulinRecord;

    const updatedUserRecords = StorageService.saveRecord(newRecord);
    setRecords([...updatedUserRecords]);
    setEditingRecord(undefined);
  };

  const handleBatchImport = (newRecords: InsulinRecord[]) => {
    if (!currentUser) return;
    
    let updatedRecords: InsulinRecord[] = [];
    newRecords.forEach(rec => {
      updatedRecords = StorageService.saveRecord(rec);
    });
    
    setRecords([...updatedRecords]);
    alert(`${newRecords.length}件のデータをインポートしました`);
    setActiveTab('logbook'); // Go to logbook to see changes
  };

  const handleDeleteRecord = (id: string) => {
    if (!currentUser) return;
    const updatedRecords = StorageService.deleteRecord(id, currentUser.id);
    setRecords([...updatedRecords]);
  };

  const handleSaveSettings = (newSettings: AppSettings) => {
    if (!currentUser) return;
    StorageService.saveSettings(newSettings, currentUser.id);
    setSettings(newSettings);
    alert('設定を保存しました');
  };

  const openEntry = (slot: TimeSlot, record?: InsulinRecord) => {
    setCurrentEntrySlot(slot);
    setEditingRecord(record);
    setIsEntryOpen(true);
  };

  // If not logged in, show Auth Screen
  if (!currentUser) {
    return <AuthScreen onLogin={handleLogin} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <Dashboard 
            user={currentUser}
            settings={settings}
            todaysRecords={records.filter(r => r.date === new Date().toISOString().split('T')[0])}
            onAddRecord={(slot) => openEntry(slot)}
          />
        );
      case 'logbook':
        return (
          <Logbook 
            records={records}
            settings={settings}
            onRecordClick={(r) => openEntry(r.slot, r)}
          />
        );
      case 'settings':
        return (
          <Settings 
            user={currentUser}
            settings={settings} 
            onSaveSettings={handleSaveSettings}
            onUpdateUser={setCurrentUser}
            onLogout={handleLogout}
            onDeleteAccount={handleDeleteAccount}
            onImportRecords={handleBatchImport}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="h-full flex flex-col bg-gray-50 max-w-md mx-auto relative shadow-2xl">
      
      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto no-scrollbar">
        {renderContent()}
      </main>

      {/* Bottom Navigation */}
      <nav className="bg-white border-t border-gray-100 flex justify-around items-center p-2 pb-safe absolute bottom-0 w-full z-40">
        <button 
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center p-3 rounded-xl transition-colors ${activeTab === 'dashboard' ? 'text-blue-600 bg-blue-50' : 'text-gray-400'}`}
        >
          <Home className="w-6 h-6 mb-1" />
          <span className="text-[10px] font-bold">ホーム</span>
        </button>
        <button 
          onClick={() => setActiveTab('logbook')}
          className={`flex flex-col items-center p-3 rounded-xl transition-colors ${activeTab === 'logbook' ? 'text-blue-600 bg-blue-50' : 'text-gray-400'}`}
        >
          <BookOpen className="w-6 h-6 mb-1" />
          <span className="text-[10px] font-bold">ノート</span>
        </button>
        <button 
          onClick={() => setActiveTab('settings')}
          className={`flex flex-col items-center p-3 rounded-xl transition-colors ${activeTab === 'settings' ? 'text-blue-600 bg-blue-50' : 'text-gray-400'}`}
        >
          <UserCircle className="w-6 h-6 mb-1" />
          <span className="text-[10px] font-bold">アカウント</span>
        </button>
      </nav>

      {/* Global Entry Modal */}
      <EntrySheet 
        isOpen={isEntryOpen} 
        onClose={() => setIsEntryOpen(false)}
        onSave={handleSaveRecord}
        onDelete={handleDeleteRecord}
        initialSlot={currentEntrySlot}
        settings={settings}
        existingRecord={editingRecord}
      />
    </div>
  );
}

export default App;