export type TimeSlot = 
  | 'breakfast_pre' | 'breakfast_post'
  | 'lunch_pre' | 'lunch_post'
  | 'dinner_pre' | 'dinner_post'
  | 'bedtime';

export enum TimeSlotCategory {
  MORNING = 'MORNING',
  NOON = 'NOON',
  EVENING = 'EVENING',
  NIGHT = 'NIGHT',
}

export interface User {
  id: string;
  email: string;
  password: string; // In a real app, this would be hashed
  name: string;
}

export interface InsulinRecord {
  id: string;
  userId: string; // Foreign key to User
  date: string; // ISO date string YYYY-MM-DD
  timestamp: number;
  slot: TimeSlot;
  glucose: number | null; // mg/dL
  insulin: number | null; // units
  note?: string;
  isCorrection?: boolean; // If true, this was an extra correction dose
}

export interface RuleSettings {
  targetBgLow: number; // e.g., 80
  targetBgHigh: number; // e.g., 140
  correctionFactor: number; // e.g., 1 unit drops 50mg/dL (simplified for this app logic as per spec: fixed +2 etc)
  doseIncreaseStep: number; // e.g., +2
  doseDecreaseStep: number; // e.g., -1
}

export interface BaseDoses {
  breakfast: number;
  lunch: number;
  dinner: number;
  bedtime: number; // Levemir
}

export interface AppSettings {
  // User specific settings
  rules: RuleSettings;
  baseDoses: BaseDoses;
  activeSlots: Record<TimeSlot, boolean>;
}

export const DEFAULT_SETTINGS: AppSettings = {
  rules: {
    targetBgLow: 80,
    targetBgHigh: 140,
    correctionFactor: 50,
    doseIncreaseStep: 2,
    doseDecreaseStep: 1,
  },
  baseDoses: {
    breakfast: 4,
    lunch: 5,
    dinner: 6,
    bedtime: 8,
  },
  activeSlots: {
    breakfast_pre: true,
    breakfast_post: true,
    lunch_pre: true,
    lunch_post: true,
    dinner_pre: true,
    dinner_post: true,
    bedtime: true,
  },
};