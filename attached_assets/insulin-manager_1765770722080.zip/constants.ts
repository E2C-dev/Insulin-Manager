import { TimeSlot, TimeSlotCategory } from './types';

export const COLORS = {
  primary: '#2563EB', // Blue-600
  danger: '#EF4444', // Red-500
  info: '#6366F1', // Indigo-500
  warning: '#F59E0B', // Amber-500
  morning: '#F97316', // Orange-500
  noon: '#EAB308', // Yellow-500
  evening: '#A855F7', // Purple-500
  night: '#6366F1', // Indigo-500
};

export const TIME_SLOT_CONFIG: Record<TimeSlot, { label: string; category: TimeSlotCategory; colorClass: string; bgClass: string }> = {
  breakfast_pre: { label: '朝食前', category: TimeSlotCategory.MORNING, colorClass: 'text-orange-500', bgClass: 'bg-orange-500' },
  breakfast_post: { label: '朝食後', category: TimeSlotCategory.MORNING, colorClass: 'text-orange-500', bgClass: 'bg-orange-500' },
  lunch_pre: { label: '昼食前', category: TimeSlotCategory.NOON, colorClass: 'text-yellow-600', bgClass: 'bg-yellow-500' }, // Darker yellow text for readability
  lunch_post: { label: '昼食後', category: TimeSlotCategory.NOON, colorClass: 'text-yellow-600', bgClass: 'bg-yellow-500' },
  dinner_pre: { label: '夕食前', category: TimeSlotCategory.EVENING, colorClass: 'text-purple-500', bgClass: 'bg-purple-500' },
  dinner_post: { label: '夕食後', category: TimeSlotCategory.EVENING, colorClass: 'text-purple-500', bgClass: 'bg-purple-500' },
  bedtime: { label: '眠前', category: TimeSlotCategory.NIGHT, colorClass: 'text-indigo-500', bgClass: 'bg-indigo-500' },
};

export const TIME_SLOTS: TimeSlot[] = [
  'breakfast_pre', 'breakfast_post',
  'lunch_pre', 'lunch_post',
  'dinner_pre', 'dinner_post',
  'bedtime'
];