import { GoogleGenAI, Type } from "@google/genai";
import { InsulinRecord, TimeSlot } from '../types';
import { generateId } from '../utils';

// Helper to safely get API key without crashing if process is undefined
const getApiKey = () => {
  try {
    if (typeof process !== 'undefined' && process.env) {
      return process.env.API_KEY;
    }
  } catch (e) {
    // Ignore error
  }
  return '';
};

// Initialize the Gemini API client
const ai = new GoogleGenAI({ apiKey: getApiKey() });

export interface ExtractedData {
  day: number;
  data: {
    slot: TimeSlot;
    glucose: number | null;
    insulin: number | null;
  }[];
}

export const AiService = {
  analyzeLogbookImage: async (base64Image: string, year: number, month: number): Promise<InsulinRecord[]> => {
    try {
      // Check if API key is available
      const apiKey = getApiKey();
      if (!apiKey) {
        throw new Error("APIキーが設定されていません。");
      }

      // Remove data URL prefix if present
      const cleanBase64 = base64Image.replace(/^data:image\/(png|jpeg|jpg);base64,/, "");

      const prompt = `
        Analyze this handwritten diabetes logbook image. 
        The columns are typically: 
        1. Date (Day of month)
        2. Breakfast Pre (Morning Pre)
        3. Breakfast Post (Morning Post)
        4. Lunch Pre
        5. Lunch Post
        6. Dinner Pre
        7. Dinner Post
        8. Bedtime

        Rows represent days.
        Cells contain:
        - Glucose values (plain numbers, e.g., 110, 95)
        - Insulin doses (often circled numbers, e.g., 4, 12). Sometimes notes like +2 are present, treat +2 as just 2 if circled, or ignore if it's a correction on top of a base dose, but usually the circled number is the dose.
        
        Extract the data into a JSON structure. 
        For each row, identify the Day.
        For each cell, identify Glucose and Insulin values. If a cell is empty or has a dash, return null.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
          parts: [
            { inlineData: { mimeType: 'image/jpeg', data: cleanBase64 } },
            { text: prompt }
          ]
        },
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                day: { type: Type.NUMBER, description: "Day of the month" },
                records: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      slot: { 
                        type: Type.STRING, 
                        enum: [
                          'breakfast_pre', 'breakfast_post',
                          'lunch_pre', 'lunch_post',
                          'dinner_pre', 'dinner_post',
                          'bedtime'
                        ]
                      },
                      glucose: { type: Type.NUMBER, nullable: true },
                      insulin: { type: Type.NUMBER, nullable: true }
                    }
                  }
                }
              }
            }
          }
        }
      });

      const rawData = JSON.parse(response.text || '[]');
      
      // Convert to InsulinRecord format
      const records: InsulinRecord[] = [];

      rawData.forEach((dayData: any) => {
        if (!dayData.day) return;

        // Construct Date String YYYY-MM-DD
        // Pad month and day
        const mStr = month.toString().padStart(2, '0');
        const dStr = dayData.day.toString().padStart(2, '0');
        const dateStr = `${year}-${mStr}-${dStr}`;
        
        // Approximate timestamps for sorting (08:00, 12:00, 19:00, 23:00)
        const getBaseHour = (slot: TimeSlot) => {
          if (slot.includes('breakfast')) return 8;
          if (slot.includes('lunch')) return 12;
          if (slot.includes('dinner')) return 19;
          return 23;
        };

        dayData.records.forEach((rec: any) => {
          if (rec.glucose === null && rec.insulin === null) return;

          const hour = getBaseHour(rec.slot as TimeSlot);
          const dateObj = new Date(year, month - 1, dayData.day, hour, 0);

          records.push({
            id: generateId(),
            userId: '', // Will be filled by the caller
            date: dateStr,
            timestamp: dateObj.getTime(),
            slot: rec.slot as TimeSlot,
            glucose: rec.glucose,
            insulin: rec.insulin,
            note: 'インポートされたデータ'
          });
        });
      });

      return records;

    } catch (error: any) {
      console.error("AI Analysis Failed:", error);
      throw new Error("画像の解析に失敗しました。もう一度試すか、鮮明な画像を使用してください。");
    }
  }
};