import { AppSettings, InsulinRecord, DEFAULT_SETTINGS } from '../types';

const KEYS = {
  RECORDS: 'insulin_app_records',
  SETTINGS_PREFIX: 'insulin_app_settings_',
};

export const StorageService = {
  // Get records only for the specific user
  getRecords: (userId: string): InsulinRecord[] => {
    try {
      const data = localStorage.getItem(KEYS.RECORDS);
      const allRecords: InsulinRecord[] = data ? JSON.parse(data) : [];
      return allRecords.filter(r => r.userId === userId);
    } catch (e) {
      console.error("Failed to load records", e);
      return [];
    }
  },

  saveRecord: (record: InsulinRecord) => {
    try {
      const data = localStorage.getItem(KEYS.RECORDS);
      const allRecords: InsulinRecord[] = data ? JSON.parse(data) : [];
      
      const index = allRecords.findIndex(r => r.id === record.id);
      if (index >= 0) {
        allRecords[index] = record;
      } else {
        allRecords.push(record);
      }
      
      // Sort by timestamp desc
      allRecords.sort((a, b) => b.timestamp - a.timestamp);
      localStorage.setItem(KEYS.RECORDS, JSON.stringify(allRecords));
      
      // Return only user's records
      return allRecords.filter(r => r.userId === record.userId);
    } catch (e) {
      return [];
    }
  },

  deleteRecord: (id: string, userId: string) => {
    const data = localStorage.getItem(KEYS.RECORDS);
    let allRecords: InsulinRecord[] = data ? JSON.parse(data) : [];
    
    allRecords = allRecords.filter(r => r.id !== id);
    localStorage.setItem(KEYS.RECORDS, JSON.stringify(allRecords));
    
    return allRecords.filter(r => r.userId === userId);
  },

  // Settings are now per user
  getSettings: (userId: string): AppSettings => {
    try {
      const data = localStorage.getItem(KEYS.SETTINGS_PREFIX + userId);
      return data ? { ...DEFAULT_SETTINGS, ...JSON.parse(data) } : DEFAULT_SETTINGS;
    } catch (e) {
      return DEFAULT_SETTINGS;
    }
  },

  saveSettings: (settings: AppSettings, userId: string) => {
    localStorage.setItem(KEYS.SETTINGS_PREFIX + userId, JSON.stringify(settings));
    return settings;
  },

  // Cleanup function for account deletion
  deleteAllUserData: (userId: string) => {
    // Delete settings
    localStorage.removeItem(KEYS.SETTINGS_PREFIX + userId);
    
    // Delete records
    const data = localStorage.getItem(KEYS.RECORDS);
    if (data) {
      const allRecords: InsulinRecord[] = JSON.parse(data);
      const remainingRecords = allRecords.filter(r => r.userId !== userId);
      localStorage.setItem(KEYS.RECORDS, JSON.stringify(remainingRecords));
    }
  }
};