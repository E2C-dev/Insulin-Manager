import { User } from '../types';
import { StorageService } from './storage';
import { generateId } from '../utils';

const KEYS = {
  USERS: 'insulin_app_users',
  CURRENT_USER_ID: 'insulin_app_current_user_id',
};

export const AuthService = {
  getUsers: (): User[] => {
    try {
      const data = localStorage.getItem(KEYS.USERS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  getCurrentUser: (): User | null => {
    const userId = localStorage.getItem(KEYS.CURRENT_USER_ID);
    if (!userId) return null;
    const users = AuthService.getUsers();
    return users.find(u => u.id === userId) || null;
  },

  register: (email: string, password: string, name: string): User => {
    const users = AuthService.getUsers();
    if (users.some(u => u.email === email)) {
      throw new Error('このメールアドレスは既に登録されています');
    }

    const newUser: User = {
      id: generateId(),
      email,
      password,
      name,
    };

    users.push(newUser);
    localStorage.setItem(KEYS.USERS, JSON.stringify(users));
    AuthService.login(email, password); // Auto login
    return newUser;
  },

  login: (email: string, password: string): User => {
    const users = AuthService.getUsers();
    const user = users.find(u => u.email === email && u.password === password);
    
    if (!user) {
      throw new Error('メールアドレスまたはパスワードが間違っています');
    }

    localStorage.setItem(KEYS.CURRENT_USER_ID, user.id);
    return user;
  },

  logout: () => {
    localStorage.removeItem(KEYS.CURRENT_USER_ID);
  },

  updateProfile: (user: User): User => {
    const users = AuthService.getUsers();
    const index = users.findIndex(u => u.id === user.id);
    if (index === -1) throw new Error('ユーザーが見つかりません');

    // Email duplicate check if email changed
    if (users[index].email !== user.email && users.some(u => u.email === user.email && u.id !== user.id)) {
      throw new Error('このメールアドレスは既に使用されています');
    }

    users[index] = user;
    localStorage.setItem(KEYS.USERS, JSON.stringify(users));
    return user;
  },

  deleteAccount: (userId: string) => {
    // 1. Remove User
    const users = AuthService.getUsers().filter(u => u.id !== userId);
    localStorage.setItem(KEYS.USERS, JSON.stringify(users));
    
    // 2. Remove Session
    if (localStorage.getItem(KEYS.CURRENT_USER_ID) === userId) {
      localStorage.removeItem(KEYS.CURRENT_USER_ID);
    }

    // 3. Remove User Data
    StorageService.deleteAllUserData(userId);
  }
};