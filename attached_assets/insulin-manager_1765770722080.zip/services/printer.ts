import { InsulinRecord, User, TimeSlot } from '../types';
import { TIME_SLOT_CONFIG } from '../constants';

export const PrinterService = {
  printLogbook: (records: InsulinRecord[], user: User, startDate: Date, endDate: Date) => {
    // 1. Prepare Data
    const recordMap: Record<string, Record<TimeSlot, InsulinRecord>> = {};
    
    // Filter and Sort
    const sortedRecords = records.filter(r => {
      const d = new Date(r.date);
      return d >= startDate && d <= endDate;
    }).sort((a, b) => a.timestamp - b.timestamp);

    sortedRecords.forEach(r => {
      if (!recordMap[r.date]) recordMap[r.date] = {} as any;
      recordMap[r.date][r.slot] = r;
    });

    // Generate Date List
    const dates: string[] = [];
    let current = new Date(startDate);
    while (current <= endDate) {
      dates.push(current.toISOString().split('T')[0]);
      current.setDate(current.getDate() + 1);
    }

    // 2. Generate HTML
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('ポップアップがブロックされました。許可してください。');
      return;
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>血糖管理ノート - ${user.name}</title>
        <style>
          body { font-family: "Helvetica Neue", Arial, "Hiragino Kaku Gothic ProN", "Hiragino Sans", Meiryo, sans-serif; padding: 20px; color: #333; }
          h1 { text-align: center; font-size: 24px; margin-bottom: 10px; }
          .header-info { display: flex; justify-content: space-between; margin-bottom: 20px; border-bottom: 2px solid #333; padding-bottom: 10px; }
          table { width: 100%; border-collapse: collapse; font-size: 12px; }
          th, td { border: 1px solid #333; padding: 4px; text-align: center; height: 30px; }
          th { background-color: #f0f0f0; font-weight: bold; }
          .weekend { background-color: #f9f9f9; }
          .bg-val { font-size: 14px; font-weight: bold; display: block; }
          .insulin-val { font-size: 11px; color: #444; border: 1px solid #666; border-radius: 50%; width: 18px; height: 18px; line-height: 18px; display: inline-block; margin-top: 2px; }
          .note { font-size: 9px; color: #666; display: block; max-width: 60px; margin: 0 auto; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
          .low { color: #dc2626; }
          .high { color: #d97706; }
          @media print {
            body { padding: 0; }
            button { display: none; }
          }
        </style>
      </head>
      <body>
        <h1>自己管理ノート</h1>
        <div class="header-info">
          <div>氏名: <strong>${user.name} 様</strong></div>
          <div>期間: ${startDate.toLocaleDateString('ja-JP')} 〜 ${endDate.toLocaleDateString('ja-JP')}</div>
        </div>

        <table>
          <thead>
            <tr>
              <th rowspan="2" style="width: 8%">日付</th>
              <th colspan="2" style="background: #fff7ed">朝</th>
              <th colspan="2" style="background: #fefce8">昼</th>
              <th colspan="2" style="background: #faf5ff">夕</th>
              <th rowspan="2" style="background: #eef2ff; width: 10%">眠前</th>
            </tr>
            <tr>
              <th style="width: 10%">前</th>
              <th style="width: 10%">後</th>
              <th style="width: 10%">前</th>
              <th style="width: 10%">後</th>
              <th style="width: 10%">前</th>
              <th style="width: 10%">後</th>
            </tr>
          </thead>
          <tbody>
            ${dates.map(dateStr => {
              const dateObj = new Date(dateStr);
              const dayData = recordMap[dateStr] || {};
              const isSunday = dateObj.getDay() === 0;
              const isSaturday = dateObj.getDay() === 6;
              const rowClass = isSunday || isSaturday ? 'weekend' : '';
              
              const renderCell = (slot: TimeSlot) => {
                const rec = dayData[slot];
                if (!rec) return '';
                
                let bgHtml = '';
                if (rec.glucose) {
                  const colorClass = rec.glucose < 70 ? 'low' : rec.glucose > 180 ? 'high' : '';
                  bgHtml = `<span class="bg-val ${colorClass}">${rec.glucose}</span>`;
                }
                
                let insHtml = '';
                if (rec.insulin !== null) {
                  insHtml = `<span class="insulin-val">${rec.insulin}</span>`;
                }

                let noteHtml = '';
                if (rec.note) {
                  noteHtml = `<span class="note">${rec.note}</span>`;
                }

                return `<td>${bgHtml}${insHtml}${noteHtml}</td>`;
              };

              return `
                <tr class="${rowClass}">
                  <td>
                    ${dateObj.getDate()} <span style="font-size:10px">(${['日','月','火','水','木','金','土'][dateObj.getDay()]})</span>
                  </td>
                  ${renderCell('breakfast_pre')}
                  ${renderCell('breakfast_post')}
                  ${renderCell('lunch_pre')}
                  ${renderCell('lunch_post')}
                  ${renderCell('dinner_pre')}
                  ${renderCell('dinner_post')}
                  ${renderCell('bedtime')}
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
        
        <div style="margin-top: 20px; text-align: center;">
          <button onclick="window.print()" style="padding: 10px 20px; font-size: 16px; cursor: pointer; background: #2563EB; color: white; border: none; border-radius: 5px;">印刷 / PDF保存</button>
          <p style="font-size: 12px; color: #666; margin-top: 10px;">※スマホの場合は「印刷」→「共有」または「PDFとして保存」を選択してください。</p>
        </div>
        <script>
          // Auto print on load option
          // window.onload = () => window.print();
        </script>
      </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
  }
};