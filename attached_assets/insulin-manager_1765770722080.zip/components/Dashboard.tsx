import React from 'react';
import { Plus, Activity, Sun, Moon, Coffee, Utensils, User as UserIcon, Droplet } from 'lucide-react';
import { AppSettings, InsulinRecord, TimeSlot, User } from '../types';
import { Card, GlucoseValue, InsulinCircle } from './Shared';
import { TIME_SLOT_CONFIG } from '../constants';

interface DashboardProps {
  user: User;
  settings: AppSettings;
  todaysRecords: InsulinRecord[];
  onAddRecord: (slot: TimeSlot) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ user, settings, todaysRecords, onAddRecord }) => {
  // Get latest record
  const latestRecord = todaysRecords.length > 0 ? todaysRecords[0] : null;

  // Determine next likely slot based on time
  const getSuggestedSlot = (): TimeSlot => {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 10) return 'breakfast_pre';
    if (hour >= 10 && hour < 12) return 'breakfast_post';
    if (hour >= 12 && hour < 14) return 'lunch_pre';
    if (hour >= 14 && hour < 17) return 'lunch_post';
    if (hour >= 17 && hour < 20) return 'dinner_pre';
    if (hour >= 20 && hour < 22) return 'dinner_post';
    return 'bedtime';
  };
  
  const suggestedSlot = getSuggestedSlot();
  const config = TIME_SLOT_CONFIG[suggestedSlot];

  // Helper to render icon based on slot category
  const getIcon = (slot: string) => {
    if (slot.includes('breakfast')) return <Coffee className="w-5 h-5" />;
    if (slot.includes('lunch')) return <Sun className="w-5 h-5" />;
    if (slot.includes('dinner')) return <Utensils className="w-5 h-5" />;
    return <Moon className="w-5 h-5" />;
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header Area */}
      <div className="bg-blue-600 p-6 pt-12 rounded-b-3xl text-white shadow-lg">
        <div className="flex justify-between items-start mb-6">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <UserIcon className="w-4 h-4 opacity-70" />
              <span className="text-sm font-semibold opacity-90">こんにちは、{user.name}さん</span>
            </div>
            <h1 className="text-2xl font-bold">今日の体調</h1>
            <p className="opacity-80 text-sm">
              {new Date().toLocaleDateString('ja-JP', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>
          <div className="bg-white/20 p-2 rounded-lg backdrop-blur-sm">
             <Activity className="w-6 h-6 text-white" />
          </div>
        </div>

        {/* Latest Reading Card */}
        <div className="bg-white text-gray-900 rounded-2xl p-5 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">
              最新測定 ({latestRecord ? TIME_SLOT_CONFIG[latestRecord.slot].label : '-'})
            </p>
            <div className="flex items-baseline gap-1">
              <span className="text-4xl font-extrabold tracking-tight">
                {latestRecord?.glucose ?? '--'}
              </span>
              <span className="text-sm font-semibold text-gray-500">mg/dL</span>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1">
            <span className="text-xs font-bold text-gray-400 uppercase">インスリン</span>
            <InsulinCircle value={latestRecord?.insulin ?? null} slot={latestRecord?.slot} />
          </div>
        </div>
      </div>

      <div className="px-5 space-y-4">
        
        {/* Base Doses Quick View (New) */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-blue-50">
          <div className="flex items-center gap-2 mb-3 pb-2 border-b border-gray-50">
            <Droplet className="w-4 h-4 text-blue-500" />
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider">基準インスリン量 (単位)</h3>
          </div>
          <div className="grid grid-cols-4 gap-2 text-center divide-x divide-gray-100">
            <div>
              <span className="text-[10px] text-orange-500 font-bold block mb-1">朝</span>
              <span className="text-xl font-bold text-gray-800">{settings.baseDoses.breakfast}</span>
            </div>
            <div>
              <span className="text-[10px] text-yellow-600 font-bold block mb-1">昼</span>
              <span className="text-xl font-bold text-gray-800">{settings.baseDoses.lunch}</span>
            </div>
            <div>
              <span className="text-[10px] text-purple-500 font-bold block mb-1">夕</span>
              <span className="text-xl font-bold text-gray-800">{settings.baseDoses.dinner}</span>
            </div>
            <div>
              <span className="text-[10px] text-indigo-500 font-bold block mb-1">眠前</span>
              <span className="text-xl font-bold text-indigo-600">{settings.baseDoses.bedtime}</span>
            </div>
          </div>
        </div>

        <h2 className="text-lg font-bold text-gray-800 px-1 pt-2">記録を追加</h2>
        
        {/* Main Smart Button */}
        <button 
          onClick={() => onAddRecord(suggestedSlot)}
          className={`w-full ${config.bgClass} text-white p-4 rounded-2xl shadow-lg shadow-blue-100 flex items-center justify-between transition-transform active:scale-98`}
        >
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-full">
              {getIcon(suggestedSlot)}
            </div>
            <div className="text-left">
              <p className="font-bold text-lg">{config.label}</p>
              <p className="text-xs opacity-90">現在時刻のおすすめ</p>
            </div>
          </div>
          <div className="bg-white text-gray-900 w-10 h-10 rounded-full flex items-center justify-center">
            <Plus className="w-6 h-6" />
          </div>
        </button>

        {/* Quick Grid */}
        <div className="grid grid-cols-4 gap-2 mt-4">
          {(Object.keys(TIME_SLOT_CONFIG) as TimeSlot[]).map((key) => {
             // Skip if disabled in settings
             if (!settings.activeSlots[key]) return null;
             const conf = TIME_SLOT_CONFIG[key];
             const isSuggested = key === suggestedSlot;
             if (isSuggested) return null; // Already shown in big button

             return (
               <button
                 key={key}
                 onClick={() => onAddRecord(key)}
                 className="flex flex-col items-center justify-center bg-white border border-gray-100 rounded-xl py-3 shadow-sm hover:bg-gray-50 active:scale-95 transition-all"
               >
                 <span className={`${conf.colorClass} mb-1`}>
                   {getIcon(key)}
                 </span>
                 <span className="text-xs font-bold text-gray-600">{conf.label}</span>
               </button>
             );
          })}
        </div>
      </div>

      {/* Today's Timeline Snippet */}
      <div className="px-5">
        <h2 className="text-lg font-bold text-gray-800 mb-3 px-1">今日の履歴</h2>
        <div className="space-y-3">
          {todaysRecords.length === 0 ? (
            <div className="text-center py-8 text-gray-400 bg-white rounded-xl border border-dashed">
              記録はまだありません
            </div>
          ) : (
            todaysRecords.map(record => (
              <Card key={record.id} className="flex items-center justify-between py-3">
                <div className="flex items-center gap-3">
                   <div className={`w-2 h-10 rounded-full ${TIME_SLOT_CONFIG[record.slot].bgClass}`} />
                   <div>
                     <p className="text-sm font-bold text-gray-700">{TIME_SLOT_CONFIG[record.slot].label}</p>
                     <p className="text-xs text-gray-400">
                        {new Date(record.timestamp).toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' })}
                     </p>
                   </div>
                </div>
                <div className="flex items-center gap-4">
                  <GlucoseValue value={record.glucose} />
                  <InsulinCircle value={record.insulin} slot={record.slot} />
                </div>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
};