import React, { useState, useEffect } from 'react';
import { X, Save, AlertCircle, Trash2, FileText } from 'lucide-react';
import { TimeSlot, AppSettings, InsulinRecord, RuleSettings } from '../types';
import { TIME_SLOT_CONFIG } from '../constants';
import { Button } from './Shared';
import { generateId } from '../utils';

interface EntrySheetProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (record: Partial<InsulinRecord>) => void;
  onDelete?: (id: string) => void;
  initialSlot: TimeSlot;
  settings: AppSettings;
  existingRecord?: InsulinRecord;
}

export const EntrySheet: React.FC<EntrySheetProps> = ({ 
  isOpen, onClose, onSave, onDelete, initialSlot, settings, existingRecord 
}) => {
  const [slot, setSlot] = useState<TimeSlot>(initialSlot);
  const [glucose, setGlucose] = useState<string>('');
  const [insulin, setInsulin] = useState<string>('');
  const [note, setNote] = useState<string>('');
  const [suggestion, setSuggestion] = useState<{ dose: number, msg: string, type: 'normal'|'warning'|'danger' } | null>(null);

  useEffect(() => {
    if (isOpen) {
      setSlot(initialSlot);
      if (existingRecord) {
        setGlucose(existingRecord.glucose?.toString() || '');
        setInsulin(existingRecord.insulin?.toString() || '');
        setNote(existingRecord.note || '');
      } else {
        setGlucose('');
        setInsulin('');
        setNote('');
      }
      setSuggestion(null);
    }
  }, [isOpen, initialSlot, existingRecord]);

  // Logic: Calculate suggestion when glucose changes
  useEffect(() => {
    if (!glucose) {
      setSuggestion(null);
      return;
    }
    const bg = parseInt(glucose);
    if (isNaN(bg)) return;

    calculateSuggestion(bg, slot, settings.rules, settings.baseDoses);
  }, [glucose, slot, settings]);

  const calculateSuggestion = (bg: number, currentSlot: TimeSlot, rules: RuleSettings, bases: any) => {
    let baseDose = 0;
    
    // Determine base dose key
    if (currentSlot.includes('breakfast')) baseDose = bases.breakfast;
    else if (currentSlot.includes('lunch')) baseDose = bases.lunch;
    else if (currentSlot.includes('dinner')) baseDose = bases.dinner;
    else if (currentSlot === 'bedtime') baseDose = bases.bedtime;

    // Rules logic
    if (currentSlot !== 'bedtime') {
      if (bg >= rules.targetBgHigh) {
        // High: Calculate correction based on factor (Standard Sliding Scale Logic)
        // Correction = (Current BG - Target High) / Factor
        const diff = bg - rules.targetBgHigh;
        const correctionUnits = rules.correctionFactor > 0 
          ? Math.floor(diff / rules.correctionFactor)
          : rules.doseIncreaseStep; // Fallback if factor is not set
        
        // Ensure strictly positive correction if strictly high, or 0
        const finalCorrection = Math.max(0, correctionUnits);
        
        const total = baseDose + finalCorrection;
        
        setSuggestion({
          dose: total,
          msg: `高血糖 (${bg}): 基本${baseDose} + 補正${finalCorrection} (効果値:${rules.correctionFactor})`,
          type: 'danger'
        });
        
        // Auto-fill insulin if empty and not editing
        if (!insulin && !existingRecord) setInsulin(total.toString());
      } else if (bg <= rules.targetBgLow) {
        // Low
        const reduction = rules.doseDecreaseStep;
        const total = Math.max(0, baseDose - reduction);
        setSuggestion({
          dose: total,
          msg: `低血糖気味 (${bg}): 基本${baseDose} - 減量${reduction}`,
          type: 'warning'
        });
        if (!insulin && !existingRecord) setInsulin(total.toString());
      } else {
        // Normal
        setSuggestion({
          dose: baseDose,
          msg: `血糖値正常: 基本投与量`,
          type: 'normal'
        });
        if (!insulin && !existingRecord) setInsulin(baseDose.toString());
      }
    } else {
      // Bedtime Rule
      if (bg <= rules.targetBgLow) {
        const reduction = 1;
        const total = Math.max(0, baseDose - reduction);
        setSuggestion({
          dose: total,
          msg: `眠前低値: レベミルを${reduction}単位減量推奨`,
          type: 'danger'
        });
         if (!insulin && !existingRecord) setInsulin(total.toString());
      } else {
         if (!insulin && !existingRecord) setInsulin(baseDose.toString());
      }
    }
  };

  const handleSave = () => {
    onSave({
      slot,
      glucose: glucose ? parseInt(glucose) : null,
      insulin: insulin ? parseInt(insulin) : null,
      note: note.trim(),
      timestamp: existingRecord ? existingRecord.timestamp : Date.now(),
      date: existingRecord ? existingRecord.date : new Date().toISOString().split('T')[0],
      id: existingRecord ? existingRecord.id : generateId(),
    });
    onClose();
  };
  
  const handleDelete = () => {
    if (existingRecord && onDelete && confirm('この記録を削除しますか？')) {
      onDelete(existingRecord.id);
      onClose();
    }
  };

  if (!isOpen) return null;

  const config = TIME_SLOT_CONFIG[slot];

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm transition-opacity" onClick={onClose} />
      
      {/* Modal */}
      <div className="relative bg-white w-full max-w-md rounded-t-2xl shadow-2xl transform transition-transform duration-300 pb-safe max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className={`p-4 rounded-t-2xl flex items-center justify-between ${config.bgClass} text-white`}>
          <div>
            <h2 className="text-xl font-bold flex items-center gap-2">
              {config.label}
              <span className="text-sm font-normal opacity-90">記録</span>
            </h2>
            <p className="text-xs opacity-80">
              {new Date().toLocaleDateString('ja-JP', { month: 'long', day: 'numeric', weekday: 'long' })}
            </p>
          </div>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-white/20">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6">
          
          {/* Inputs */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-500">血糖値 (mg/dL)</label>
              <input
                type="number"
                inputMode="numeric"
                pattern="[0-9]*"
                className="w-full text-3xl font-bold p-3 border-b-2 border-gray-200 focus:border-blue-500 outline-none text-center bg-gray-50 rounded-t-md"
                placeholder="---"
                value={glucose}
                onChange={(e) => setGlucose(e.target.value)}
                autoFocus
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-500">インスリン (単位)</label>
              <input
                type="number"
                inputMode="numeric"
                pattern="[0-9]*"
                className="w-full text-3xl font-bold p-3 border-b-2 border-gray-200 focus:border-blue-500 outline-none text-center bg-gray-50 rounded-t-md"
                placeholder="-"
                value={insulin}
                onChange={(e) => setInsulin(e.target.value)}
              />
            </div>
          </div>

          {/* Suggestion Box */}
          {suggestion && (
            <div className={`p-4 rounded-xl border flex gap-3 ${
              suggestion.type === 'danger' ? 'bg-red-50 border-red-200 text-red-700' :
              suggestion.type === 'warning' ? 'bg-orange-50 border-orange-200 text-orange-700' :
              'bg-blue-50 border-blue-200 text-blue-700'
            }`}>
              <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-sm">推奨投与量: {suggestion.dose}単位</p>
                <p className="text-xs opacity-90 mt-1">{suggestion.msg}</p>
              </div>
            </div>
          )}

          {/* Note Input */}
          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-500 flex items-center gap-2">
              <FileText className="w-4 h-4" /> メモ
            </label>
            <textarea
              className="w-full p-3 border border-gray-200 rounded-xl bg-gray-50 focus:border-blue-500 focus:bg-white outline-none transition-colors text-sm"
              rows={2}
              placeholder="食事内容、体調など..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
          </div>

          {/* Quick Slot Switching */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">タイミング変更</label>
            <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
              {Object.entries(TIME_SLOT_CONFIG).map(([key, conf]) => (
                <button
                  key={key}
                  onClick={() => setSlot(key as TimeSlot)}
                  className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-colors ${
                    slot === key 
                      ? `${conf.bgClass} text-white shadow-md` 
                      : 'bg-gray-100 text-gray-500'
                  }`}
                >
                  {conf.label}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-2 flex flex-col gap-3">
            <Button onClick={handleSave} fullWidth className="flex items-center justify-center gap-2">
              <Save className="w-5 h-5" />
              保存する
            </Button>
            
            {existingRecord && onDelete && (
              <button 
                onClick={handleDelete}
                className="w-full py-3 text-red-500 text-sm font-bold flex items-center justify-center gap-2 hover:bg-red-50 rounded-xl transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                削除する
              </button>
            )}
          </div>

        </div>
      </div>
    </div>
  );
};