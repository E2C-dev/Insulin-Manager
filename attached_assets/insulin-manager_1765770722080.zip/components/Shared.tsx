import React from 'react';
import { TIME_SLOT_CONFIG } from '../constants';
import { TimeSlot } from '../types';

// --- Card ---
export const Card: React.FC<{ children: React.ReactNode; className?: string; onClick?: () => void }> = ({ children, className = '', onClick }) => (
  <div onClick={onClick} className={`bg-white rounded-xl shadow-sm p-4 ${className}`}>
    {children}
  </div>
);

// --- Button ---
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
  fullWidth?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ children, variant = 'primary', fullWidth, className = '', ...props }) => {
  const baseStyle = "px-4 py-3 rounded-xl font-semibold transition-all active:scale-95 disabled:opacity-50 disabled:active:scale-100";
  const variants = {
    primary: "bg-blue-600 text-white shadow-md shadow-blue-200",
    secondary: "bg-white text-blue-600 border border-blue-100 shadow-sm",
    danger: "bg-red-500 text-white shadow-md shadow-red-200",
    ghost: "bg-transparent text-gray-500 hover:bg-gray-100",
  };
  
  return (
    <button 
      className={`${baseStyle} ${variants[variant]} ${fullWidth ? 'w-full' : ''} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};

// --- Insulin Circle ---
export const InsulinCircle: React.FC<{ value: number | null; slot?: TimeSlot }> = ({ value, slot }) => {
  if (value === null || value === undefined) return <span className="text-gray-300">-</span>;

  const colorClass = slot ? TIME_SLOT_CONFIG[slot].colorClass : 'text-blue-600';
  const borderClass = slot ? slot.includes('bedtime') ? 'border-indigo-500' : 
                      slot.includes('dinner') ? 'border-purple-500' :
                      slot.includes('lunch') ? 'border-yellow-500' : 'border-orange-500' 
                      : 'border-blue-600';

  return (
    <div className={`
      inline-flex items-center justify-center 
      w-8 h-8 rounded-full border-2 font-bold text-sm
      ${colorClass} ${borderClass} bg-white
    `}>
      {value}
    </div>
  );
};

// --- Glucose Display ---
export const GlucoseValue: React.FC<{ value: number | null }> = ({ value }) => {
  if (value === null || value === undefined) return <span className="text-gray-300 text-sm">-</span>;
  
  // Highlight high/low
  let color = "text-gray-900";
  if (value < 70) color = "text-red-500";
  else if (value > 180) color = "text-yellow-600";

  return <span className={`font-bold text-lg ${color}`}>{value}</span>;
};