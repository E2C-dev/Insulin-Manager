import React, { useState } from 'react';
import { AppSettings, TimeSlot, User, InsulinRecord } from '../types';
import { TIME_SLOT_CONFIG } from '../constants';
import { Button } from './Shared';
import { Save, UserCircle, LogOut, Trash2, Camera, UploadCloud, Settings as SettingsIcon } from 'lucide-react';
import { AuthService } from '../services/auth';
import { ImportWizard } from './ImportWizard';

interface SettingsProps {
  user: User;
  settings: AppSettings;
  onSaveSettings: (s: AppSettings) => void;
  onUpdateUser: (u: User) => void;
  onLogout: () => void;
  onDeleteAccount: () => void;
  onImportRecords: (records: InsulinRecord[]) => void;
}

export const Settings: React.FC<SettingsProps> = ({ 
  user, settings, onSaveSettings, onUpdateUser, onLogout, onDeleteAccount, onImportRecords 
}) => {
  const [localSettings, setLocalSettings] = React.useState<AppSettings>(settings);
  const [userName, setUserName] = React.useState(user.name);
  const [userEmail, setUserEmail] = React.useState(user.email);
  const [isImportOpen, setIsImportOpen] = useState(false);

  const handleBaseDoseChange = (key: keyof AppSettings['baseDoses'], value: string) => {
    setLocalSettings(prev => ({
      ...prev,
      baseDoses: { ...prev.baseDoses, [key]: parseInt(value) || 0 }
    }));
  };

  const handleRuleChange = (key: keyof AppSettings['rules'], value: string) => {
    setLocalSettings(prev => ({
      ...prev,
      rules: { ...prev.rules, [key]: parseInt(value) || 0 }
    }));
  };

  const toggleSlot = (slot: TimeSlot) => {
    setLocalSettings(prev => ({
      ...prev,
      activeSlots: { ...prev.activeSlots, [slot]: !prev.activeSlots[slot] }
    }));
  };

  const handleSaveAll = () => {
    // 1. Save Settings
    onSaveSettings(localSettings);
    
    // 2. Update User Profile if changed
    if (userName !== user.name || userEmail !== user.email) {
      try {
        const updatedUser = AuthService.updateProfile({
          ...user,
          name: userName,
          email: userEmail
        });
        onUpdateUser(updatedUser);
      } catch (e: any) {
        alert(e.message);
        return;
      }
    }
  };

  const handleDeleteAccountConfirm = () => {
    if (confirm('本当にアカウントを削除しますか？\nこの操作は取り消せず、すべての記録が削除されます。')) {
      onDeleteAccount();
    }
  };

  return (
    <div className="pb-24 bg-gray-50 min-h-full">
      <ImportWizard 
        isOpen={isImportOpen} 
        onClose={() => setIsImportOpen(false)} 
        currentUser={user}
        onImport={onImportRecords}
      />

      <div className="bg-white p-4 border-b sticky top-0 z-20 flex justify-between items-center shadow-sm">
        <h1 className="text-xl font-bold text-gray-800">アカウント / 設定</h1>
        <Button onClick={handleSaveAll} className="!py-2 !px-4 text-sm flex gap-2">
          <Save className="w-4 h-4" /> 保存
        </Button>
      </div>

      <div className="p-4 space-y-6">

        {/* User Profile Section (Top priority) */}
        <section className="bg-white rounded-xl p-5 shadow-sm border border-blue-100">
          <div className="flex items-center gap-2 mb-4 border-b pb-2">
            <UserCircle className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-bold text-blue-600">プロフィール情報</h2>
          </div>
          <div className="space-y-4">
            <div className="space-y-1">
              <label className="text-sm font-medium text-gray-600">お名前</label>
              <input 
                type="text" 
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                className="w-full p-2 border rounded-lg bg-gray-50 font-bold"
              />
            </div>
            <div className="space-y-1">
              <label className="text-sm font-medium text-gray-600">メールアドレス</label>
              <input 
                type="email" 
                value={userEmail}
                onChange={(e) => setUserEmail(e.target.value)}
                className="w-full p-2 border rounded-lg bg-gray-50 font-bold"
              />
            </div>
            <p className="text-xs text-gray-400 mt-2">
              ※この情報はPDF出力時などに氏名として使用されます。
            </p>
          </div>
        </section>

        {/* Import Section */}
        <section className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl p-5 shadow-lg text-white">
          <div className="flex items-center gap-2 mb-2">
            <Camera className="w-5 h-5" />
            <h2 className="text-lg font-bold">データインポート</h2>
          </div>
          <p className="text-sm opacity-90 mb-4">
            手書きの自己管理ノートを撮影して、AIで自動的にデータを取り込みます。
          </p>
          <button 
            onClick={() => setIsImportOpen(true)}
            className="w-full bg-white text-blue-600 font-bold py-3 px-4 rounded-lg flex items-center justify-center gap-2 shadow-sm hover:bg-gray-50 transition-colors"
          >
            <UploadCloud className="w-5 h-5" />
            写真から読み取る
          </button>
        </section>

        <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider pl-1 mt-8 mb-2 flex items-center gap-2">
          <SettingsIcon className="w-4 h-4" /> アプリ設定
        </h3>

        {/* Base Doses Section */}
        <section className="bg-white rounded-xl p-5 shadow-sm">
          <h2 className="text-lg font-bold text-gray-700 mb-4 border-b pb-2">基準インスリン投与量</h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-sm font-medium text-gray-600">朝食 (単位)</label>
              <input 
                type="number" 
                value={localSettings.baseDoses.breakfast}
                onChange={(e) => handleBaseDoseChange('breakfast', e.target.value)}
                className="w-full p-2 border rounded-lg bg-gray-50 font-bold"
              />
            </div>
            <div className="space-y-1">
              <label className="text-sm font-medium text-gray-600">昼食 (単位)</label>
              <input 
                type="number" 
                value={localSettings.baseDoses.lunch}
                onChange={(e) => handleBaseDoseChange('lunch', e.target.value)}
                className="w-full p-2 border rounded-lg bg-gray-50 font-bold"
              />
            </div>
            <div className="space-y-1">
              <label className="text-sm font-medium text-gray-600">夕食 (単位)</label>
              <input 
                type="number" 
                value={localSettings.baseDoses.dinner}
                onChange={(e) => handleBaseDoseChange('dinner', e.target.value)}
                className="w-full p-2 border rounded-lg bg-gray-50 font-bold"
              />
            </div>
            <div className="space-y-1">
              <label className="text-sm font-medium text-indigo-600">眠前 (レベミル)</label>
              <input 
                type="number" 
                value={localSettings.baseDoses.bedtime}
                onChange={(e) => handleBaseDoseChange('bedtime', e.target.value)}
                className="w-full p-2 border border-indigo-100 rounded-lg bg-indigo-50 font-bold text-indigo-700"
              />
            </div>
          </div>
        </section>

        {/* Rules Section */}
        <section className="bg-white rounded-xl p-5 shadow-sm">
          <h2 className="text-lg font-bold text-red-500 mb-4 border-b pb-2">自動調整ルール</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-gray-600">低血糖アラート (mg/dL以下)</label>
              <input 
                type="number" 
                value={localSettings.rules.targetBgLow}
                onChange={(e) => handleRuleChange('targetBgLow', e.target.value)}
                className="w-24 p-2 border rounded-lg text-right font-bold"
              />
            </div>
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-gray-600">高血糖アラート (mg/dL以上)</label>
              <input 
                type="number" 
                value={localSettings.rules.targetBgHigh}
                onChange={(e) => handleRuleChange('targetBgHigh', e.target.value)}
                className="w-24 p-2 border rounded-lg text-right font-bold"
              />
            </div>
             <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-gray-600">インスリン効果値 (1単位で下がる量)</label>
              <input 
                type="number" 
                value={localSettings.rules.correctionFactor}
                onChange={(e) => handleRuleChange('correctionFactor', e.target.value)}
                className="w-24 p-2 border rounded-lg text-right font-bold"
              />
            </div>
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-gray-600">追加打ちデフォルト (+)</label>
              <input 
                type="number" 
                value={localSettings.rules.doseIncreaseStep}
                onChange={(e) => handleRuleChange('doseIncreaseStep', e.target.value)}
                className="w-24 p-2 border rounded-lg text-right font-bold"
              />
            </div>
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-gray-600">減量単位 (-)</label>
              <input 
                type="number" 
                value={localSettings.rules.doseDecreaseStep}
                onChange={(e) => handleRuleChange('doseDecreaseStep', e.target.value)}
                className="w-24 p-2 border rounded-lg text-right font-bold"
              />
            </div>
          </div>
        </section>

        {/* Display Settings */}
        <section className="bg-white rounded-xl p-5 shadow-sm">
          <h2 className="text-lg font-bold text-gray-700 mb-4 border-b pb-2">表示設定</h2>
          <p className="text-xs text-gray-400 mb-3">使用しないタイミングを非表示にできます</p>
          <div className="space-y-2">
            {Object.keys(localSettings.activeSlots).map((key) => {
               const k = key as TimeSlot;
               return (
                 <label key={k} className="flex items-center justify-between p-2 hover:bg-gray-50 rounded-lg">
                   <span className={`font-bold ${TIME_SLOT_CONFIG[k].colorClass}`}>{TIME_SLOT_CONFIG[k].label}</span>
                   <input 
                     type="checkbox"
                     checked={localSettings.activeSlots[k]}
                     onChange={() => toggleSlot(k)}
                     className="w-5 h-5 accent-blue-600"
                   />
                 </label>
               );
            })}
          </div>
        </section>

        {/* Account Actions */}
        <section className="space-y-3 pt-4 border-t">
          <Button onClick={onLogout} variant="secondary" fullWidth className="flex items-center justify-center gap-2">
            <LogOut className="w-4 h-4" />
            ログアウト
          </Button>
          <Button onClick={handleDeleteAccountConfirm} variant="ghost" fullWidth className="text-red-500 hover:bg-red-50 hover:text-red-600 flex items-center justify-center gap-2">
            <Trash2 className="w-4 h-4" />
            アカウントを削除する
          </Button>
        </section>

        {/* Bottom Save Button */}
        <Button onClick={handleSaveAll} fullWidth className="mt-4 flex items-center justify-center gap-2 py-4 shadow-xl">
          <Save className="w-5 h-5" />
          設定を保存する
        </Button>
      </div>
    </div>
  );
};