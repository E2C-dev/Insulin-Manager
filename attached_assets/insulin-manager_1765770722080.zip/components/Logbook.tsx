import React, { useState, useMemo } from 'react';
import { InsulinRecord, AppSettings, TimeSlot, User } from '../types';
import { TIME_SLOT_CONFIG } from '../constants';
import { ChevronLeft, ChevronRight, Calendar, FileDown } from 'lucide-react';
import { PrinterService } from '../services/printer';
import { AuthService } from '../services/auth';

interface LogbookProps {
  records: InsulinRecord[];
  settings: AppSettings;
  onRecordClick: (record: InsulinRecord) => void;
}

// Helper to format date range
const formatDateRange = (start: Date, end: Date) => {
  return `${start.toLocaleDateString('ja-JP', { month: 'numeric', day: 'numeric' })} - ${end.toLocaleDateString('ja-JP', { month: 'numeric', day: 'numeric' })}`;
};

// Compact Cell Component
const CompactCell: React.FC<{
  pre?: InsulinRecord;
  post?: InsulinRecord;
  onClick: (r: InsulinRecord) => void;
  isBedtime?: boolean;
}> = ({ pre, post, onClick, isBedtime }) => {
  const hasData = pre || post;

  if (!hasData) {
    return <div className="h-full w-full bg-gray-50/30"></div>;
  }

  const renderMiniRecord = (rec?: InsulinRecord, label?: string) => {
    if (!rec) return <div className="h-1/2"></div>;
    return (
      <div 
        onClick={(e) => { e.stopPropagation(); onClick(rec); }}
        className="h-1/2 flex items-center justify-between px-1 cursor-pointer hover:bg-blue-50 transition-colors rounded-sm"
      >
        <div className="flex items-center gap-1">
          {label && <span className="text-[9px] text-gray-400 font-medium leading-none">{label}</span>}
          <span className={`text-xs font-bold leading-none ${
            (rec.glucose || 0) > 180 ? 'text-yellow-600' : 
            (rec.glucose || 0) < 70 ? 'text-red-500' : 'text-gray-700'
          }`}>
            {rec.glucose || '-'}
          </span>
        </div>
        {rec.insulin !== null && (
          <div className="bg-blue-100 text-blue-700 text-[9px] font-bold px-1.5 py-0.5 rounded-full leading-none min-w-[1.2rem] text-center">
            {rec.insulin}
          </div>
        )}
      </div>
    );
  };

  if (isBedtime) {
    return (
      <div className="h-full flex flex-col justify-center border-l border-gray-100">
        {renderMiniRecord(pre)}
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col border-l border-gray-100 divide-y divide-gray-100">
      {renderMiniRecord(pre, '前')}
      {renderMiniRecord(post, '後')}
    </div>
  );
};

export const Logbook: React.FC<LogbookProps> = ({ records, settings, onRecordClick }) => {
  // Pagination State (0 = Current 2 weeks, 1 = Previous 2 weeks, etc.)
  const [pageOffset, setPageOffset] = useState(0);

  // Calculate Date Range
  const { startDate, endDate, dateList } = useMemo(() => {
    const end = new Date();
    // Shift end date back by 14 days * offset
    end.setDate(end.getDate() - (pageOffset * 14));
    
    const start = new Date(end);
    start.setDate(start.getDate() - 13); // 14 days window (including end date)

    // Generate list of dates strings (YYYY-MM-DD) in this range (descending)
    const dates = [];
    let current = new Date(end);
    while (current >= start) {
      dates.push(current.toISOString().split('T')[0]);
      current.setDate(current.getDate() - 1);
    }
    return { startDate: start, endDate: end, dateList: dates };
  }, [pageOffset]);

  // Group records for the current view
  const recordsMap = useMemo(() => {
    const map: Record<string, Record<TimeSlot, InsulinRecord>> = {};
    records.forEach(r => {
      // Only include records in range
      if (r.date >= startDate.toISOString().split('T')[0] && r.date <= endDate.toISOString().split('T')[0]) {
        if (!map[r.date]) map[r.date] = {} as any;
        map[r.date][r.slot] = r;
      }
    });
    return map;
  }, [records, startDate, endDate]);

  const hasNext = pageOffset > 0;

  const handlePrint = () => {
    const user = AuthService.getCurrentUser();
    if (!user) return;
    // Print the currently viewed 2 weeks
    PrinterService.printLogbook(records, user, startDate, endDate);
  };

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Header & Pagination */}
      <div className="p-3 border-b bg-white z-20 flex items-center justify-between shadow-sm">
        <button 
          onClick={() => setPageOffset(prev => prev + 1)}
          className="p-2 rounded-full hover:bg-gray-100 active:bg-gray-200 text-blue-600"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        <div className="flex flex-col items-center">
          <div className="flex items-center gap-2 text-gray-800 font-bold">
            <Calendar className="w-4 h-4 text-blue-500" />
            <span>{formatDateRange(startDate, endDate)}</span>
          </div>
          <span className="text-xs text-gray-400 font-medium">2週間表示</span>
        </div>

        <div className="flex items-center">
           <button 
            onClick={() => hasNext && setPageOffset(prev => prev - 1)}
            disabled={!hasNext}
            className={`p-2 rounded-full ${hasNext ? 'hover:bg-gray-100 active:bg-gray-200 text-blue-600' : 'text-gray-300'}`}
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Tools Bar */}
      <div className="px-4 py-2 bg-gray-50 flex justify-end border-b">
         <button 
           onClick={handlePrint}
           className="flex items-center gap-1 text-xs font-bold text-blue-600 bg-white px-3 py-1.5 rounded-full border border-blue-100 shadow-sm active:scale-95"
         >
           <FileDown className="w-3.5 h-3.5" />
           PDF出力 / 印刷
         </button>
      </div>
      
      {/* Compact Table */}
      <div className="flex-1 overflow-y-auto no-scrollbar relative">
        <table className="w-full table-fixed border-collapse">
          <thead className="sticky top-0 z-10 bg-gray-50 shadow-sm text-xs text-gray-500">
            <tr>
              <th className="w-[14%] py-2 border-b font-bold">日付</th>
              <th className="w-[21.5%] py-2 border-b font-bold text-orange-500 bg-orange-50/50">朝</th>
              <th className="w-[21.5%] py-2 border-b font-bold text-yellow-600 bg-yellow-50/50">昼</th>
              <th className="w-[21.5%] py-2 border-b font-bold text-purple-500 bg-purple-50/50">夕</th>
              <th className="w-[21.5%] py-2 border-b font-bold text-indigo-500 bg-indigo-50/50">眠前</th>
            </tr>
          </thead>
          <tbody className="text-sm divide-y divide-gray-100">
            {dateList.map((dateStr) => {
              const dayData = recordsMap[dateStr] || {};
              const dateObj = new Date(dateStr);
              const isWeekend = dateObj.getDay() === 0 || dateObj.getDay() === 6;
              const dateColor = dateObj.getDay() === 0 ? 'text-red-500' : dateObj.getDay() === 6 ? 'text-blue-500' : 'text-gray-600';

              return (
                <tr key={dateStr} className="h-14">
                  {/* Date Column */}
                  <td className={`text-center border-r border-gray-100 ${isWeekend ? 'bg-gray-50/50' : 'bg-white'}`}>
                    <div className={`flex flex-col items-center justify-center leading-tight ${dateColor}`}>
                      <span className="text-xs font-bold">{dateObj.getDate()}</span>
                      <span className="text-[9px] opacity-70">{dateObj.toLocaleDateString('ja-JP', { weekday: 'short' })}</span>
                    </div>
                  </td>

                  {/* Breakfast Cell (Pre/Post Stacked) */}
                  <td className="p-0 align-top">
                    <CompactCell 
                      pre={dayData['breakfast_pre']} 
                      post={dayData['breakfast_post']} 
                      onClick={onRecordClick} 
                    />
                  </td>

                  {/* Lunch Cell (Pre/Post Stacked) */}
                  <td className="p-0 align-top">
                    <CompactCell 
                      pre={dayData['lunch_pre']} 
                      post={dayData['lunch_post']} 
                      onClick={onRecordClick} 
                    />
                  </td>

                  {/* Dinner Cell (Pre/Post Stacked) */}
                  <td className="p-0 align-top">
                    <CompactCell 
                      pre={dayData['dinner_pre']} 
                      post={dayData['dinner_post']} 
                      onClick={onRecordClick} 
                    />
                  </td>

                  {/* Bedtime Cell (Single) */}
                  <td className="p-0 align-top">
                    <CompactCell 
                      pre={dayData['bedtime']} 
                      isBedtime={true}
                      onClick={onRecordClick} 
                    />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        
        {/* Helper text for empty state or footer */}
        <div className="p-4 text-center text-xs text-gray-300">
          - 期間終了 -
        </div>
      </div>
    </div>
  );
};