import React, { useState, useRef } from 'react';
import { Camera, Upload, X, Check, Loader2, Calendar } from 'lucide-react';
import { Button } from './Shared';
import { AiService } from '../services/ai';
import { InsulinRecord, User } from '../types';
import { TIME_SLOT_CONFIG } from '../constants';

interface ImportWizardProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (records: InsulinRecord[]) => void;
  currentUser: User;
}

export const ImportWizard: React.FC<ImportWizardProps> = ({ isOpen, onClose, onImport, currentUser }) => {
  const [step, setStep] = useState<'upload' | 'preview'>('upload');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [extractedRecords, setExtractedRecords] = useState<InsulinRecord[]>([]);
  
  // Date Selection for context
  const today = new Date();
  const [targetYear, setTargetYear] = useState(today.getFullYear());
  const [targetMonth, setTargetMonth] = useState(today.getMonth() + 1);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setSelectedImage(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const processImage = async () => {
    if (!selectedImage) return;

    setIsLoading(true);
    try {
      const records = await AiService.analyzeLogbookImage(selectedImage, targetYear, targetMonth);
      // Attach current User ID
      const userRecords = records.map(r => ({ ...r, userId: currentUser.id }));
      setExtractedRecords(userRecords);
      setStep('preview');
    } catch (e: any) {
      alert(e.message || 'エラーが発生しました');
    } finally {
      setIsLoading(false);
    }
  };

  const handleConfirmImport = () => {
    onImport(extractedRecords);
    onClose();
    // Reset state
    setTimeout(() => {
      setStep('upload');
      setSelectedImage(null);
      setExtractedRecords([]);
    }, 500);
  };

  const removeRecord = (id: string) => {
    setExtractedRecords(prev => prev.filter(r => r.id !== id));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-white">
      {/* Header */}
      <div className="p-4 border-b flex items-center justify-between bg-gray-50 safe-top">
        <h2 className="text-lg font-bold">手書きノートからインポート</h2>
        <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-200">
          <X className="w-6 h-6" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        
        {step === 'upload' && (
          <div className="space-y-8 flex flex-col h-full">
            
            {/* 1. Date Context */}
            <div className="bg-blue-50 p-4 rounded-xl border border-blue-100">
              <div className="flex items-center gap-2 mb-2 text-blue-700 font-bold">
                <Calendar className="w-5 h-5" />
                <span>対象年月を選択</span>
              </div>
              <p className="text-xs text-blue-600/80 mb-3">
                ノートには「日」しか書かれていないため、何年何月の記録か指定してください。
              </p>
              <div className="flex gap-4">
                <div className="flex-1">
                  <label className="text-xs font-bold text-gray-500 block mb-1">年</label>
                  <select 
                    value={targetYear} 
                    onChange={(e) => setTargetYear(parseInt(e.target.value))}
                    className="w-full p-2 rounded-lg border bg-white font-bold"
                  >
                    {Array.from({length: 5}, (_, i) => today.getFullYear() - i).map(y => (
                      <option key={y} value={y}>{y}年</option>
                    ))}
                  </select>
                </div>
                <div className="flex-1">
                  <label className="text-xs font-bold text-gray-500 block mb-1">月</label>
                  <select 
                    value={targetMonth} 
                    onChange={(e) => setTargetMonth(parseInt(e.target.value))}
                    className="w-full p-2 rounded-lg border bg-white font-bold"
                  >
                    {Array.from({length: 12}, (_, i) => i + 1).map(m => (
                      <option key={m} value={m}>{m}月</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* 2. Image Selection */}
            <div className="flex-1 flex flex-col items-center justify-center border-2 border-dashed border-gray-300 rounded-2xl bg-gray-50 relative overflow-hidden">
              {selectedImage ? (
                <img src={selectedImage} alt="Preview" className="w-full h-full object-contain" />
              ) : (
                <div className="text-center p-6">
                  <Camera className="w-12 h-12 text-gray-300 mx-auto mb-2" />
                  <p className="text-gray-400 font-bold">写真を撮るか<br/>ライブラリから選択</p>
                </div>
              )}
              
              <input 
                ref={fileInputRef}
                type="file" 
                accept="image/*" 
                className="absolute inset-0 opacity-0 cursor-pointer"
                onChange={handleFileChange}
              />
            </div>

            <Button 
              onClick={processImage} 
              disabled={!selectedImage || isLoading}
              fullWidth
              className="flex items-center justify-center gap-2 py-4"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  AIが解析中...
                </>
              ) : (
                <>
                  <Upload className="w-5 h-5" />
                  読み取り開始
                </>
              )}
            </Button>
          </div>
        )}

        {step === 'preview' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
               <h3 className="font-bold text-gray-700">読み取り結果 ({extractedRecords.length}件)</h3>
               <span className="text-xs text-gray-400">誤りがある場合は削除してください</span>
            </div>

            <div className="space-y-2">
              {extractedRecords.length === 0 ? (
                 <div className="p-8 text-center text-gray-400 bg-gray-50 rounded-xl">
                    データが見つかりませんでした。
                 </div>
              ) : (
                extractedRecords.map((rec) => (
                  <div key={rec.id} className="flex items-center justify-between bg-white p-3 rounded-xl border border-gray-100 shadow-sm">
                    <div className="flex items-center gap-3">
                       <div className={`w-1 h-8 rounded-full ${TIME_SLOT_CONFIG[rec.slot].bgClass}`} />
                       <div>
                         <p className="text-sm font-bold">{new Date(rec.date).getDate()}日 ({new Date(rec.date).toLocaleDateString('ja-JP', {weekday: 'short'})})</p>
                         <p className="text-xs text-gray-500">{TIME_SLOT_CONFIG[rec.slot].label}</p>
                       </div>
                    </div>
                    <div className="flex items-center gap-4">
                      {rec.glucose && (
                        <div className="text-right">
                          <span className="text-xs text-gray-400 block">血糖</span>
                          <span className="font-bold">{rec.glucose}</span>
                        </div>
                      )}
                      {rec.insulin && (
                        <div className="text-right">
                           <span className="text-xs text-gray-400 block">単位</span>
                           <span className="font-bold text-blue-600">{rec.insulin}</span>
                        </div>
                      )}
                      <button 
                        onClick={() => removeRecord(rec.id)}
                        className="p-2 text-gray-300 hover:text-red-500"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t safe-bottom flex gap-3">
              <Button onClick={() => setStep('upload')} variant="secondary" className="flex-1">
                やり直す
              </Button>
              <Button onClick={handleConfirmImport} fullWidth className="flex-[2] flex items-center justify-center gap-2">
                <Check className="w-5 h-5" />
                全て保存する
              </Button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};