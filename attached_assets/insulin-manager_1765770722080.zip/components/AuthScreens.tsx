import React, { useState } from 'react';
import { Button } from './Shared';
import { Activity, Mail, Lock, User, ArrowRight } from 'lucide-react';
import { AuthService } from '../services/auth';
import { User as UserType } from '../types';

interface AuthScreenProps {
  onLogin: (user: UserType) => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onLogin }) => {
  const [isLoginView, setIsLoginView] = useState(true);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      if (isLoginView) {
        const user = AuthService.login(email, password);
        onLogin(user);
      } else {
        if (!name || !email || !password) throw new Error('全ての項目を入力してください');
        const user = AuthService.register(email, password, name);
        onLogin(user);
      }
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-full flex flex-col items-center justify-center p-6 bg-gradient-to-b from-blue-600 to-blue-500 text-white">
      <div className="w-full max-w-sm">
        {/* Logo / Header */}
        <div className="flex flex-col items-center mb-10">
          <div className="bg-white p-4 rounded-2xl shadow-xl mb-4">
            <Activity className="w-10 h-10 text-blue-600" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight">Insulin Manager</h1>
          <p className="opacity-80 mt-2">血糖値とインスリンの管理をシンプルに</p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-2xl p-8 text-gray-900">
          <h2 className="text-xl font-bold mb-6 text-center text-gray-800">
            {isLoginView ? 'ログイン' : 'アカウント作成'}
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm font-bold text-center">
                {error}
              </div>
            )}

            {!isLoginView && (
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-500 uppercase">お名前</label>
                <div className="relative">
                  <User className="w-5 h-5 absolute left-3 top-3 text-gray-400" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:border-blue-500 focus:bg-white outline-none font-bold"
                    placeholder="ニックネーム"
                  />
                </div>
              </div>
            )}

            <div className="space-y-1">
              <label className="text-xs font-bold text-gray-500 uppercase">メールアドレス</label>
              <div className="relative">
                <Mail className="w-5 h-5 absolute left-3 top-3 text-gray-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:border-blue-500 focus:bg-white outline-none font-bold"
                  placeholder="name@example.com"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-gray-500 uppercase">パスワード</label>
              <div className="relative">
                <Lock className="w-5 h-5 absolute left-3 top-3 text-gray-400" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:border-blue-500 focus:bg-white outline-none font-bold"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <Button type="submit" fullWidth className="mt-4 flex justify-center items-center gap-2">
              {isLoginView ? 'ログインする' : '登録する'}
              <ArrowRight className="w-4 h-4" />
            </Button>
          </form>

          <div className="mt-6 pt-6 border-t text-center">
            <p className="text-sm text-gray-500 mb-2">
              {isLoginView ? 'アカウントをお持ちでないですか？' : 'すでにアカウントをお持ちですか？'}
            </p>
            <button
              onClick={() => {
                setIsLoginView(!isLoginView);
                setError('');
              }}
              className="text-blue-600 font-bold hover:underline"
            >
              {isLoginView ? '新しくアカウントを作成' : 'ログイン画面へ'}
            </button>
          </div>
        </div>
        
        <p className="text-center text-xs text-white/60 mt-8">
          ※データはブラウザ内にのみ保存されます。<br/>キャッシュを削除するとデータは消去されます。
        </p>
      </div>
    </div>
  );
};